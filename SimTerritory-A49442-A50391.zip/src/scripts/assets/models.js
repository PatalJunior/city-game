export default {
  "under-construction": {
    "type": "zone",
    "filename": "construction-small.glb",
    "scale": 3
  },
  "residential-A1": {
    "type": "zone",
    "filename": "building-house-block-big.glb"
  },
  "residential-B1": {
    "type": "zone",
    "filename": "building-house-family-small.glb"
  },
  "residential-C1": {
    "type": "zone",
    "filename": "building-house-family-large.glb"
  },
  "residential-A2": {
    "type": "zone",
    "filename": "building-block-4floor-short.glb",
  },
  "residential-B2": {
    "type": "zone",
    "filename": "building-block-4floor-corner.glb",
  },
  "residential-C2": {
    "type": "zone",
    "filename": "building-block-5floor.glb",
  },
  "residential-A3": {
    "type": "zone",
    "filename": "building-office-balcony.glb"
  },
  "residential-B3": {
    "type": "zone",
    "filename": "building-office-pyramid.glb"
  },
  "residential-C3": {
    "type": "zone",
    "filename": "building-office-tall.glb"
  },
  "road-straight": {
    "type": "road",
    "filename": "tile-road-straight.glb",
    "castShadow": false
  },
  "road-end": {
    "type": "road",
    "filename": "tile-road-end.glb",
    "castShadow": false
  },
  "road-corner": {
    "type": "road",
    "filename": "tile-road-curve.glb",
    "castShadow": false
  },
  "road-three-way": {
    "type": "road",
    "filename": "tile-road-intersection-t.glb",
    "castShadow": false
  },
  "road-four-way": {
    "type": "road",
    "filename": "tile-road-intersection.glb",
    "castShadow": false
  },
  "grass": {
    "type": "terrain",
    "filename": "tile-plain_grass.glb",
    "castShadow": false
  },
}