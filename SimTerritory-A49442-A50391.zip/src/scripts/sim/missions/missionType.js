export const MissionType = {
    residential: 'residential',
    road: 'road',
    commercial: 'commercial',
    industrial: 'industrial',
    resident: 'resident',
  }