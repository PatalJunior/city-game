export const BuildingStatus = {
  NoRoadAccess: 'no-road-access',
  Ok: 'ok'
}