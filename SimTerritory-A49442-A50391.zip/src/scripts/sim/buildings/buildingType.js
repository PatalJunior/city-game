export const BuildingType = {
  residential: 'residential',
  road: 'road',
}